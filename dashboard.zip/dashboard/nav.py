import streamlit as st

def render_sidebar():
    with st.sidebar:
        st.markdown("### 🏢 Enterprise RAG Platform")
        st.caption("Adaptive Multi-Agent System")
        st.markdown("---")

        current = st.session_state.get("page", "home")

        pages = [
            ("🏠 Home", "home"),
            ("📤 Upload Documents", "upload"),
            ("💬 Chat Console", "chat"),
            ("⚖️ Compare Documents", "compare"),
            ("🕸️ Knowledge Graph", "graph"),
            ("⚙️ Settings", "settings"),
            ("🧠 Memory", "memory"),
            ("📜 History", "history"),
        ]

        for label, page_key in pages:
            # Active button styling
            btn_type = "primary" if current == page_key else "secondary"
            if st.button(label, key=f"nav_{page_key}", use_container_width=True, type=btn_type):
                st.session_state["page"] = page_key
                st.rerun()

        st.markdown("---")
        st.caption("👤 Ahemaraju Siri • NMR Engineering College")